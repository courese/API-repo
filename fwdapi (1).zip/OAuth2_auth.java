package Exercise;

import static io.restassured.RestAssured.given;

public class OAuth2_auth {

	public void Oauth() {
		String token="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";
		given().
		auth().oauth2(token).
		when().get("https://api.github.com/user/repos").
		then().
		statusCode(200);
	}
}
