package RestAssured.API;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class Delete_request {
	@Test
	
	public void delete() {

    baseURI = "http://localhost:3000/";

    given().
    when().
        delete("/users/6").
    then().
        statusCode(200).
        log().all();

	}

}
