package RestAssured.API;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.json.simple.JSONObject;
import org.testng.Assert;

public class practice1 {
	//@Test
	public void sample1() {

		Response response = RestAssured.get("https://reqres.in/api/users?page=2");
		System.out.println(response);
		System.out.println(response.getTime());

		int statusCode = response.statusCode();
		System.out.println(statusCode);

		String contentType = response.getContentType();
		System.out.println(contentType);

		Assert.assertEquals(contentType, "application/json; charset=utf-8");
		Assert.assertEquals(statusCode, "201");

	}
	//@Test
	public void sample2() {
		Response response = RestAssured.get("https://reqres.in/api/users?page=2");     
		System.out.println(response);
		System.out.println(response.getStatusCode());
		System.out.println(response.getBody().asString());
		
		System.out.println(response.getBody());
		
		int statuscode = response.getStatusCode();
		Assert.assertEquals(statuscode, 201);
		
	}
	//@Test
	public void sample3() {
		given().get("http://localhost:3000/users")
		
		.then()
		.statusCode(200)
		.body("Firstname", hasItems("Maha","Gowtham"));
	}
	@Test
	public void sample4() {
		
		JSONObject request = new JSONObject();
		request.put("first_name" ,"class");
		request.put("last_name" ,"method");
		System.out.println(request);
		
		given().
		body(request.toJSONString())
		.when()
		.put("https://reqres.in/api/users/2").then().statusCode(200);
		
	}
	
	

}
