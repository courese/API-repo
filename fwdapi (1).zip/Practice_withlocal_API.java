package RestAssured.API;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
public class Practice_withlocal_API {
	@Test
	public void getrequest() {
		baseURI= "http://localhost:3000/";
		
		given().
			param("views","300")
		.when()
			.get("/users")
		.then()
			.statusCode(200)
		.and()
			.log().all();
	}

}
