package RestAssured.API;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
public class Post_request {
	@Test
	public void post() {
		baseURI = "http://localhost:3000/";
		JSONObject use = new JSONObject();
		use.put("id", "8");
		use.put("Firstname", "zzz");
		use.put("Lastname", "yyy");
		use.put("views", "50");
		
		given().
			body(use.toJSONString()).
			header("ContentType","Application/json").
		when().
			post("/users").
		then().	
			statusCode(201).and().log().all();
		
		
		
	}

}
