package RestAssured.API;


import java.util.HashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class test_02 {
	//@Test
//	public void post_withmap()
//	{
//		 Map<String, Object> map = new HashMap<String, Object>();
//		 map.put("name", "Maha");
//		 map.put("job", "IT");
//		 System.out.println(map);
//		 JSONObject request = new JSONObject(map);
//		 System.out.println(request); // printing with json
//		 System.out.println(request.toJSONString()); // converting all key value pair into " quotes
//	}
//	@Test
//	public void POST_withoutmap()
//	{
//		JSONObject name = new JSONObject();
//		name.put("name", "lakshmi");
//		name.put("task", "learning");
//		System.out.println(name);
//		
//		given().body(name.toJSONString())
//		.when()
//		.post("https://reqres.in/api/users")
//		.then()
//		.statusCode(201)
//		.log().all();
//	}
//	@Test
//	public void put()
//	{
//		JSONObject name = new JSONObject();
//		name.put("name", "lakshmi");
//		name.put("task", "learning");
//		System.out.println(name);
//		
//		given().body(name.toJSONString())
//		.when()
//		.put("https://reqres.in/api/users/2")
//		.then()
//		.statusCode(200)
//		.log().all();
//	}
	
//	@Test
//	public void PATCH()
//	{
//		JSONObject name = new JSONObject();
//		name.put("name", "lakshmi");
//		name.put("task", "learning");
//		System.out.println(name);
//		
//		given().body(name.toJSONString())
//		.when()
//		.patch("https://reqres.in/api/users/2")
//		.then()
//		.statusCode(200)
//		.log().all();
//	}
	
	public void DELETE()
	{
		given()
		.delete("https://reqres.in/api/users/2")
		.then()
		.statusCode(200)
		.log().all();
	}
	}
