package utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
	static XSSFWorkbook book;
	static XSSFSheet page ;
	public Excel(String pathanme, String sheetname) throws IOException //constructor
	{
		String read = "./Folder/excel1.xlsx";
		book = new XSSFWorkbook(read);
		page = book.getSheet(sheetname);
	}
	
	public static void rowcount() throws IOException
	{
	
		int totalusedrows=page.getPhysicalNumberOfRows();
		System.out.println("no OF ROWS IS :" +totalusedrows);		
	}
	
	public static void readdata(int rownum, int colnum) throws IOException
	{
		DataFormatter format = new DataFormatter();
		Object value = format.formatCellValue(page.getRow(rownum).getCell(colnum)); //object - it can include both string & int
		//String value = page.getRow(1).getCell(0).getStringCellValue();
		System.out.println(value);
	}
	
//	public static void main(String[] args) throws IOException {
//		
//		rowcount();
//		readdata();
//	}

}
