package Exercise;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;
import org.hamcrest.Matcher;
import static org.hamcrest.Matchers.*;

public class Request_1 extends base_class{
	
	@Test
	public void get() {
		
		given().
		baseUri(baseURI).
		header("Content-Type", "application/json; charset=utf-8").
			when().
				get("/posts/1").
			then().
				assertThat().
				time(lessThan(5000L)).
				and().
				statusCode(200).
				and().
				
				body("id", equalTo(1)).
				body("userId", equalTo(1)).
				body("title", equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit")).
				body("body", containsString("quia et suscipit\nsuscipit recusandae ")).
				body("id", notNullValue()).
				body("title", not(empty())).
				body("$", hasKey("title")).and().
				log().all();
				
					
			
		
	}

}
