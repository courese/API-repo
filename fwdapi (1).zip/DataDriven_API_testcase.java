package DataDriven_API;

import org.json.simple.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



import static io.restassured.RestAssured.*;

public class DataDriven_API_testcase extends dataprovider_test{

	@Test (dataProvider = "provider")
	public void POST( String Firstname, String Lastname, int views, int id)
	{
		JSONObject entry = new JSONObject();
		entry.put("Firstname", Firstname);
		entry.put("Lastname", Lastname);
		entry.put("views", views);
		entry.put("id", id);
	
		baseURI = "http://localhost:3000/";
		given().
		//contentType(ContentType.JSON).accept(ContentType.JSON).
		//header("ContentType","Application/json").
		body(entry.toJSONString()). // to convert the file in a json format
		when().
		post("/users").
		then().
		statusCode(201).
		log().all();

}
	
	@DataProvider(name = "deletedata")
	public Object[] deletingdata(){
	    return new Object[] {
	       "ggg"
	    };
	}

	//@Test(dataProvider = "deletedata")
	public void delete(int id) {
	    // Setting up the base URI
	    baseURI = "http://localhost:3000";
	 
	    // Sending the delete request
	    when().
	        delete("/users/" + id).
	    then().
	        statusCode(200).
	        log().all();
	}
	
	@Parameters({"id" , "views"})  // parameter will take teh value from the testng file. so convert this method into testng
	//@Test
	public void delete2(int id) {
		
		System.out.println("value of id is: "+id);
	    // Setting up the base URI
	    baseURI = "http://localhost:3000";
	 
	    // Sending the delete request
	    when().
	        delete("/users/" + id).
	    then().
	        statusCode(200).
	        log().all();
	}
}
	
	
	
	
