package RestAssured.API;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class Patch_request {
	@Test
	public void patch() {
		
	        baseURI = "http://localhost:3000/";

	        given().
	        when().
	            get("/users/9acc").
	        then().
	            statusCode(200).
	            log().all();

	        // Prepare the JSON object for the PATCH request
	        JSONObject user = new JSONObject();
	        user.put("Lastname", "R");

	        // Perform the PATCH request
	        given().
	            header("Content-Type", "application/json").
	            body(user.toJSONString()).
	        when().
	            patch("/users/9acc").
	        then().
	            statusCode(200).
	            log().all();
	    }
	}

