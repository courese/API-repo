package RestAssured.API;


import org.testng.Assert;
import org.testng.annotations.Test;
//import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import io.restassured.response.Response;
import io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;


public class test01_get {
	
	@Test
	
	public void sample1() {
		//Response response = RestAssured.get("https://reqres.in/api/users?page=2");
		Response response = get("https://reqres.in/api/users?page=2");
		System.out.println(response.getStatusCode());
		System.out.println(response.getBody());
		System.out.println(response.asString());
		System.out.println(response.getHeader("content-type"));
		System.out.println(response.getStatusLine());
		System.out.println(response.getTime());
		
		int stauscode = response.getStatusCode();
		Assert.assertEquals(stauscode, 201);
	}

	@Test
	public void test_02()
	{
		  given()
	        .get("https://reqres.in/api/users?page=2")
	    .then()
	        .statusCode(200);

	    given()
	        .get("https://reqres.in/api/users?page=2")
	    .then()
	        .statusCode(200)
	        .body("data.id[0]", equalTo(5));
	}
	
	@Test
	public void sample2()
	{
		  given()
	        .get("https://reqres.in/api/users?page=2")
	    .then()
	        .statusCode(200)
	        .body("data.id[1]", equalTo(8))
	        .body("data.first_name", hasItems("Michael", "Lindsay"))
	        .log().all(); //log the response on the console

	    

	}
	
}
