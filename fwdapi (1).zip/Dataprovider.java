package RestAssured.API;
import org.json.simple.JSONObject;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class Dataprovider {

	// @DataProvider(name = "sample")
	    public Object[][] name() {
	        return new Object[][] {
	            {"A", "B", 10, 4},
	            {"C", "D", 20, 5}
	        };
	    }

	// @Test (dataProvider = "sample")
		public void data( String Firstname, String Lastname, int views, int id)
		{
			JSONObject entry = new JSONObject();
			entry.put("Firstname", Firstname);
			entry.put("Lastname", Lastname);
			entry.put("views", views);
			entry.put("id", id);
		
			baseURI = "http://localhost:3000/";
			given().
			//contentType(ContentType.JSON).accept(ContentType.JSON).
			//header("ContentType","Application/json").
			body(entry.toJSONString()). // to convert the file in a json format
			when().
			post("/users").
			then().
			statusCode(201).
			log().all();
		}
		
		@DataProvider(name = "deleting")
	    public Object[] deletingdata() {
	        return new Object[] {
	            6
	        };
	    }

		
	    @Test(dataProvider = "deleting")
	    public void delete1(int id) {
	    	baseURI = "http://localhost:3000/";
	        given()
	          
	        .when()
	            .delete("/users/" + id)
	        .then()
	            .statusCode(200)
	            .log().all(); 
	    }

}

