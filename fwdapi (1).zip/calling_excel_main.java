package utils;

import java.io.IOException;

public class calling_excel_main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String read = "./Folder/excel1.xlsx";
		String page = "Sheet1";
		Excel output = new Excel(read, page);
		output.rowcount();
		output.readdata(1,0);
		output.readdata(1,1);
		output.readdata(1,2);
		

	}

}
