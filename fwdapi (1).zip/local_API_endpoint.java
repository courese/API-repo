package RestAssured.API;


import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;


public class local_API_endpoint {
	//@Test
	public void get()
	{
		baseURI = "http://localhost:3000/";
		given().
		param("views", "100").  //param -  shows the specified datas entry
			get("/users").
		then().
		statusCode(200).
		log().all();
	}
	//@Test
	public void post()
	{
		JSONObject entry = new JSONObject();
		entry.put("Firstname", "lakshmi");
		entry.put("Lastname", "R");
		entry.put("views", "300");
	
		baseURI = "http://localhost:3000/";
		given().
		contentType(ContentType.JSON).accept(ContentType.JSON).
		header("ContentType","Application/json").
		body(entry.toJSONString()). // to convert the file in a json format
		when().
		post("/users").
		then().
		statusCode(201).
		log().all();
	}
	//@Test
    public void patch() {
        // Setting up the base URI
        baseURI = "http://localhost:3000";

        // Creating the JSON object with the data to be updated
        JSONObject entry = new JSONObject();
        entry.put("lastname", "Rajamohan");

        // Sending the PATCH request
        given().
            contentType(ContentType.JSON).
            accept(ContentType.JSON).
            body(entry.toJSONString()). // Converting the JSONObject to JSON string
        when().
            patch("/users/3").
        then().
            statusCode(200).
            log().all();
    }
    //@Test
	public void put() {
        // Creating the JSON object with the data to be updated
        JSONObject entry = new JSONObject();
		entry.put("Firstname", "Prabala");
		entry.put("Lastname", "Rajamohan");
		entry.put("views", "300");
		
		 // Setting up the base URI
        baseURI = "http://localhost:3000";
        
        // Sending the PATCH request
        given().
            contentType(ContentType.JSON).
            accept(ContentType.JSON).
            body(entry.toJSONString()). // Converting the JSONObject to JSON string
        when().
            put("/users/3").
        then().
            statusCode(200).
            log().all();
    }
    @Test
    public void delete() {
        // Setting up the base URI
        baseURI = "http://localhost:3000";
     
        // Sending the delete request
        when().
            delete("/users/3").
        then().
            statusCode(200).
            log().all();
    }
}

