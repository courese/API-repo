package RestAssured.API;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;


import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import org.json.simple.JSONObject;

public class Put_request {
@Test 
	public void put() {
		baseURI = "http://localhost:3000/";
		JSONObject use = new JSONObject();
		use.put("id", "8");
		use.put("Firstname", "***");
		use.put("Lastname", "yyy");
		use.put("views", "150");
		
		given().
			body(use.toJSONString()).
			header("ContentType","Application/json").
		when().
			put("/users/7").
		then().	
			statusCode(201).and().log().all();
		
	}
}
