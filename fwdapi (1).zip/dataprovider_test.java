package DataDriven_API;

import org.testng.annotations.DataProvider;

public class dataprovider_test {

	@DataProvider(name="provider")
	public Object[][] dataforpost() {     //Object[][] = 2 dimensional array fincluding string & int
//		Object[][] data = new Object[2][4];
//		data[0][0] = "aaa";
//		data[0][1] ="bbb";
//		data[0][2] =400;
//		data[0][3] = 4;
//		
//		data[1][0] ="ccc";
//		data[1][1] ="ddd";
//		data[1][2] =500;
//		data[1][3] = 5;
//		return data;
		
		return new Object[][] {
			{"eee", "fff", 250,6},
			{"ggg", "hhh", 300, 7}
		};
			
		}
	@DataProvider(name = "deletedata")
	public Object[] deletingdata(){
	    return new Object[] {
	       7
	    };
	}

}
