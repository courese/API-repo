package Exercise;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import org.hamcrest.Matcher;
import static org.hamcrest.Matchers.*;

public class Basic_auth extends base_class {
	@Test
	public void basic() {
		
		given().
			spec(requestSpec).
			contentType(ContentType.JSON).
		when().
			get("https://postman-echo.com/basic-auth").
		then().
			assertThat().
			body("authenticated", equalTo(true)).
			statusCode(200);
		
		
		
	}

}
