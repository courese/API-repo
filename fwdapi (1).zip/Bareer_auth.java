package Exercise;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;


public class Bareer_auth {
	@Test
	public void bareer() {
		String token="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";
		given().
		header("Authorization","bearer "+token).
		when().get("https://api.github.com/user/repos").
		then().
		statusCode(200);
	}

}
