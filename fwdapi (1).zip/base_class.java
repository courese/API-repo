package Exercise;

import org.testng.annotations.BeforeClass;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class base_class  {

	@BeforeClass
	public void base() {

		RestAssured.baseURI= "https://jsonplaceholder.typicode.com";
	}

	static RequestSpecification requestSpec;
	public void basicauth() {
		  requestSpec = RestAssured.given()
                 .header("Content-Type", "application/json")
                 .auth().basic("username", "password");

	}

}
