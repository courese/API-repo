package RestAssured.API;

import static io.restassured.RestAssured.*;
import org.hamcrest.Matcher.*;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class sample_exercise {
	@Test
	public void view() {
		given().when().
		get("https://dummy.restapiexample.com/api/v1/employees").
		then().
		assertThat().
		statusCode(200).
		and().
		assertThat().
		body("data[1].employee_age", equalTo(63)).
		log().all();
	}

}
